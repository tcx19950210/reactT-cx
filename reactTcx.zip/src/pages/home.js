import React from 'react';
// import logo from './logo.svg';
// import './App.css';
import {Button,Icon} from 'antd'

function Home() {
  return (
    <div className="App">
      <Button type='primary'>123</Button>
    </div>
  );
}

export default Home;